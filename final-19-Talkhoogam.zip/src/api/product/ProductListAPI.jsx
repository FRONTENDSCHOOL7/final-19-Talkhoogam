import { useRecoilValue } from "recoil";
import loginToken from "../../recoil/loginToken";

const ProductListAPI = async (newAccountname) => {
    
    const token = useRecoilValue(loginToken);
    // const token = localStorage.getItem("userToken");
    const url = "https://api.mandarin.weniv.co.kr";

    try {
        console.log("뭐냐 ??",token)
        const res = await fetch(`${url}/product/${newAccountname}`,{
            method: "GET",
            headers: {
                Authorization : `Bearer ${token}`,
                "Content-type": "application/json",
            },
        });

        const data = await res.json();
        return data;
    } catch (error) {
        console.log("API 응답에 실패하였습니다." ,error);
    };
    
};

export default ProductListAPI;