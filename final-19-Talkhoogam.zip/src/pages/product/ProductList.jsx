import React, { useState } from 'react'
import {LayoutStyle, LayoutInsideStyle} from "../../styles/LayoutStyled";
import BasicHeader from '../../components/header/BasicHeader';
import { useRecoilValue } from 'recoil';
import accountname from '../../recoil/accountname';
import ProductListAPI from '../../api/product/ProductListAPI';

export default function ProductList() {
    
    const newAccountname = useRecoilValue(accountname);
    const [productData, setProductData] = useState();
    const [loading, setLoading] = useState(false);
    console.log(newAccountname);
        
    const onClickHandler = async () => {
    
    try {
        const list = await ProductListAPI(newAccountname);
        // console.log("여긴?")
        setLoading(true); // 데이터 로딩 중임을 표시
        // setProductData(list);
        console.log("리스트!!!", list);
    } catch (error) {
        console.error('데이터를 불러오는 동안 에러가 발생했습니다: ', error);
    } finally {
        setLoading(false); // 데이터 로딩 완료
    }
    };

    return (
        <LayoutStyle>
            <BasicHeader></BasicHeader>
            <LayoutInsideStyle>
                <div>
                    <h1>상품 게시물 정보</h1>
                    <button type='button' onClick={onClickHandler}>리스트조회</button>
                    <p></p>

                    {/* {productData ? (
                        <ul>
                        {productData.map((product) => (
                            <li key={product.id}>{product.name}</li>
                        ))}
                        </ul>
                    ) : (
                        <p>데이터를 불러오는 중...</p>
                    )} */}
                </div>
            </LayoutInsideStyle>
        </LayoutStyle>
    )
}
