import React from "react";

export default function Welcome() {
  return <div>Welcome</div>;
}
