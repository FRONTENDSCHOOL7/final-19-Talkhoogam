import { useRecoilValue } from "recoil";
import loginToken from "../../recoil/loginToken";

const GetFollowerFeedListAPI = async () => {
    // const token = useRecoilValue(loginToken);
    const token = localStorage.getItem("userToken");
    console.log("토큰! : " , token)
        const url = "https://api.mandarin.weniv.co.kr";

        try {
            const res = await fetch(`${url}/post/feed`, {
                method: "GET",
                headers: {
                    Authorization : `Bearer ${token}`,
                    "Content-type": "application/json",
                },
            });
            const data = await res.json()
            // console.log("데타!", data)
            return data.posts;
        } catch (error) {
            return error;
        };
};

export default GetFollowerFeedListAPI